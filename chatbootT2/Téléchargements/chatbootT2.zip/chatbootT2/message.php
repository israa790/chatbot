<!DOCTYPE html>
<html lang="en">
    <head>
    <link rel="stylesheet" href="./wp-content/plugins/chatbootT2/style.css">
    </head>
<body>

<?php
$heure = date('h:i');
$added_on = date('Y-m-d h:i:s');

// connection m3a l BD
$conn = mysqli_connect("localhost", "root", "", "bot") or die("Database Error");



// ajax ye5edh message mtaa luser

$getMesg = mysqli_real_escape_string($conn, $_POST['text']);
if ($getMesg == "categories") {
    $check_data = "SELECT wp_terms.name FROM wp_terms 
    LEFT JOIN wp_term_taxonomy ON wp_terms.term_id = wp_term_taxonomy.term_id
    WHERE wp_term_taxonomy.taxonomy = 'product_cat';";
}

else {
    $check_data = "SELECT replies FROM chatbot WHERE queries LIKE '%$getMesg%'";
}


//requette eli temchy lel base bech tlawej 3al kelma eli fil message 
//$check_data = "SELECT replies FROM chatbot WHERE queries LIKE '%$getMesg%'";
$run_query = mysqli_query($conn, $check_data) or die("Error");


//si la requête de l'utilisateur correspond à la requête de la base de données,
//nous afficherons la réponse, sinon elle passera à une autre instruction
if (mysqli_num_rows($run_query) > 0) {
    //fetching replay mn DB
    if ($getMesg == "categories") {
        while ($row = mysqli_fetch_assoc($run_query)) {
            $categorie_name=$row['name'];
            $replay= "<button type='button' class='categories_button' id='$categorie_name' >".$categorie_name ."</button>". "</br>";
            echo $replay."<br>";
        }
    } 
   
    else {
        $fetch_data = mysqli_fetch_assoc($run_query);
        $replay = $fetch_data['replies'];
        //stockage de la réponse à une variable que nous enverrons à ajax
        echo $replay;
    }
} else {
    $replay = "Sorry can't be able to understand you!";
    echo $replay;
}


//user storage 
mysqli_query($conn, "insert into message(message,added_on,type) values('$getMesg','$added_on','user')");
mysqli_query($conn, "insert into message(message,added_on,type) values('$replay','$added_on','bot')");
?>
 
</body>
</html>